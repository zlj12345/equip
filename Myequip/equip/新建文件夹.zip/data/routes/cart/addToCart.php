<?php
require_once("../../controllers/cart.controller.php");
addToCart();