<?php
header("Content-Type:application/json");
require_once("../../controllers/cart.controller.php");
getCart();